import numpy as np
from scipy.sparse import lil_matrix, csr_matrix
import UtilFunctions

""" ----------------------------------------------------------------
------------------ STATE
--------------------------------------------------------------------
"""
class State:
    idState = 0
    labelState = ""

    def __init__(self, idState, labelState):
        self.idState = idState
        self.labelState = labelState

    def __repr__(self):
        return "<St %s %s>" % (self.idState, self.labelState)

    def __str__(self):
        return "idSt:%s , labelSt: %s" % (self.idState, self.labelState)

    def __getitem__(self, idx):
        if idx == 0:
            return self.idState
        elif idx==1:
            return self.labelState


""" ----------------------------------------------------------------
------------------ TRANSITION
--------------------------------------------------------------------
"""
class Transition:
    fromSt = 0
    toSt = 0
    probTran = 0.0
   

    def __init__(self, fromSt, toSt, prob):
        self.fromSt = int(fromSt)
        self.toSt = int(toSt)
        self.probTran = float(prob)

    def __repr__(self):
        return "Tr(%s,%s,%s)" % (self.fromSt, self.toSt, self.probTran)

    def __getitem__(self, idx):
        if idx == 0 :
            return self.fromSt
        elif idx == 1 :
            return self.toSt
        elif idx == 2 :
            return self.probTran

""" ----------------------------------------------------------------
------------------ DISCRETE TIME MARKOV CHAIN
--------------------------------------------------------------------
"""
class DTMC:

    'stateList - List of tuples (idxS,labelS)'
    stateList = []
    """dictionary is transition Matrix
       key : idS
       body : transition
    """
    transitionMatrix = {}
    'initial states'
    initialSt = []
    """indexDict 
       key : idS
       body : index
    """
    indexDict = {}
    'size of dtmc'
    n = 0

    def __init__(self, stateList, transitionMatrix,initialSt):
        self.stateList = stateList
        self.transitionMatrix = transitionMatrix
        self.initialSt = initialSt
        '--- compute indexDict based on StateList'
        idStateList = self.getIdStateList()
        self.indexDict = UtilFunctions.get_IndexDict(idStateList)
        '--- compute size of DTMC'
        self.n = len(self.stateList)

    def displayDTMC(self):
        print "---- DTMC ----"
        print "States : ", len(self.stateList)
        print "Initial State : ", self.initialSt
        print "Transition Matrix :"
        for item in self.transitionMatrix.items():
            print item
        'print "State - Action List: \n", self.actionDict.items()'
        print " ---------- "

    def getIdStateList(self):
        return [ state.idState for state in self.stateList]

    def getIdStateSet(self):
        return set([elem[0] for elem in self.stateList])

    def getTransitionList(self,idState):
        return self.transitionMatrix.get(idState)

    'Transitions without Probabilities'
    def getNonProbabilisticTM(self):
        idxStList = self.getIdStateSet()
        resList = []
        for st in idxStList:
            transList = self.transitionMatrix[st]
            resList = resList + [(tran[0], tran[1] ) for tran in transList]
        return resList

    def getNonProbabilisticTM(self,idxState):
         return UtilFunctions.eliminateDuplicates ( [((trans[0],trans[1])) for trans in (self.transitionMatrix[idxState])])

    'Function that returns the probab function as matrix'
    def getMatrixProb(self):
        matrix = csr_matrix((self.n, self.n))

        for idState in self.indexDict.keys():
            'get transitionList'
            transitionList = self.getTransitionList(idState)
            for trans in transitionList:
                fromIndex = self.indexDict.get(trans.fromSt)
                toIndex = self.indexDict.get(trans.toSt)
                matrix[fromIndex,toIndex] = trans.probTran
            '-- end for --'
        '-- end for --'
        return matrix

"""
------------------------------------------------------------------
"""
