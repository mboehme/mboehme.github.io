
import ReadFiles, MainFunctions, time

"""
import ReadPopularNews, MainFunctions, PerturbedClickStream
import StatisticalEstimations
import sys, pdb

"""

"""
--------------- MAIN --------------------------------
"""
if __name__ == "__main__":


    'start time'
    start_time = time.time()
    

    '1--------- Create DTMC ----------------------------'
    dtmcStr = ReadFiles.convert_toDtmc()
    dtmcStr.displayDTMC()

    '2---- Read Target States for computing LR  --------'
    targetList = ReadFiles.readTargetFile()

    '3---- Read Perturbation File ----------------------'
    pertDict = ReadFiles.readPerturbationFile(dtmcStr)


    '4---- Compute Condition Number  -------------------'
    MainFunctions.computeLongRunKappa(dtmcStr,targetList,pertDict)

    elapsed_time = time.time() - start_time
    print "elapsed time: " , elapsed_time


"""
------------ END MAIN -------------------------------------
"""
