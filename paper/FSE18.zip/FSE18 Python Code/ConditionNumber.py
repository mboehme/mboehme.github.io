import UtilFunctions, ReachProb
from scipy.sparse import csr_matrix, lil_matrix


def computeCN(dtmcStr,targetList,pertDict):

    '1. Compute Testing Matrix'
    A = ReachProb.computeTestingMatrix_Total(dtmcStr, targetList)

    if A.sum() == 0:
        print "A is 0"
        return 0

    '2. Compute TargetVector'
    b = ReachProb.computeTargetVector_Total(dtmcStr, targetList)
    if b.sum() == 0:
        print "b is 0"
        return 0

    '3. Compute res1V of DTMC'
    res1V = myfunCN(A,b,100)

    ' 4 - get index of the initial state. RULE : only one state is INITIAL'
    initialState = dtmcStr.initialSt[0]
    indexInitState = dtmcStr.indexDict[initialState.idState]

    '5. Compute a CN for each sub-vector of x'
    cnList = []
    for subVectorId in pertDict.keys():
        'a. Get position of variables based on A'
        posIndexVarList = getPositionVariables(dtmcStr,subVectorId,pertDict,A)

        'b. Get CMatrix List based on posIndexVarList'
        clusterH = pertDict.get(subVectorId)
        cList = getCMatrixList(dtmcStr,targetList,clusterH)

        'c. Compute coefList for each CMatrix'
        coefList = []
        for cMatrix in cList:
            'if cmatrix is non-zero'
            if cMatrix.sum() !=  0:
                cB = cMatrix.dot(res1V)
                print "cMatrix: ", cMatrix
                print "cB " , cB
                res =  myfunCN(A,cB,100)
                print "cb + A*cb + A^2*cb + ... ", res
                coef = res[indexInitState,0]
                coefList.append(coef)
            else:
                'it means that the variable is in targeList then cB'
                cB = createCB(dtmcStr.n,targetList,dtmcStr.indexDict,clusterH)
                print "nw_cB " , cB
                res =  myfunCN(A,cB,100)
                print "cb + A*cb + A^2*cb + ... ", res
                coef = res[indexInitState,0]
                coefList.append(coef)
        '-- end for --'
        'd. Compute CN for the clusterH'
        condNum = 0
        if len(coefList) > 1:
            'get maximum and minimum cn'
            maxCN = max(coefList)
            minCN = min(coefList)
            'compute the condition number'
            condNum = (maxCN - minCN) / 2
        elif len(cnList) == 1:
            condNum = (coefList[0]) / 2
        '--- print coef --- '
        print "cMatrix: ",cMatrix , " -- coefList: ", coefList
        cnList.append(condNum)
    '-- end for --'

    '6. Compute KAPPA'
    print "cnList : ", cnList
    kappa = max(cnList)
    'print "MAX condNum: ", kappa'
    return  kappa


'------------------------------------------------------------------------'


"""  -----------------------------------------------------------------------
    FUNCTION IMPORTANT : COMPUTE CN = b + Ab + A^2.b + ...
---------------------------------------------------------------------------
"""
def myfunCN(A,b,n):
    sumT = b
    Ac = A
    for i in  range(1,n):
        z = Ac.dot(b)
        sumT = sumT + z
        Ac = A.dot(Ac)
    return sumT
'------------------------------------------------------------------------'

"""
---- Compute the position of variables ----
"""
def getPositionVariables(dtmc,subVectorId,pertDict,A):
    
    'get clusterH'
    clusterH = pertDict.get(subVectorId)

    posIndexVarList = []
    
    for clusterVar in clusterH:
        varSubList = []
        for (fromSt,toSt) in clusterVar:
            fromIndex = dtmc.indexDict.get(fromSt)
            toIndex = dtmc.indexDict.get(toSt)
            if A[fromIndex,toIndex]!=0:
                varSubList.append((fromIndex,toIndex))
        '-- end for --'
        posIndexVarList.append(varSubList)
    '-- end for --'
    return posIndexVarList

'------------------------------------------------------------------------'

"""
---- Compute the CMatrix List 
"""
def getCMatrixList(dtmc,targetList,clusterH):
    
    cMatrixList = []

    'get index of target set'
    targetIdxs = [dtmc.indexDict[targSt] for targSt in targetList]

    for clusterVar in clusterH:
        CMatrix = lil_matrix((dtmc.n,dtmc.n))
        for (i,j) in clusterVar:
            if j not in targetIdxs:
                CMatrix[i,j] = 1
        '-- end for (i,j) --'
        cMatrixList.append(CMatrix)
    '-- end for --'

    print "nro de CMatrixList: ", len(cMatrixList)
    return cMatrixList
'------------------------------------------------------------------------'


"""
---- Compute the CMatrix List attached ClusterVar
"""
def getCMatrixListClusterVar(dtmc,targetList,clusterH):
    
    cMatrixList = []

    'get index of target set'
    targetIdxs = [dtmc.indexDict[targSt] for targSt in targetList]

    for clusterVar in clusterH:
        CMatrix = lil_matrix((dtmc.n,dtmc.n))
        for (i,j) in clusterVar:
            if j not in targetIdxs:
                CMatrix[i,j] = 1
        '-- end for (i,j) --'
        cMatrixList.append((clusterVar,CMatrix))
    '-- end for --'

    print "nro de CMatrixList: ", len(cMatrixList)
    return cMatrixList
'------------------------------------------------------------------------'






"""
Function that create a res matrix = C * b
"""

def createCB(n,targetList,indexDict,clusterH):

    cB = csr_matrix((n,1))
    
    'get index of target set'
    targetIdxs = [indexDict[targSt] for targSt in targetList]

    for clusterVar in clusterH:
        for(i,j) in clusterVar:
            if j in targetIdxs:
                cB[i,0] = 1
    '-- end for --'

    return cB
'------------------------------------------------------------------------'

"""
---- Function that return a Dict of every variable and their coeficients
"""
def linearFragmentReach(dtmcStr,targetList,pertDict):


    '1. Compute Testing Matrix'
    A = ReachProb.computeTestingMatrix_Total(dtmcStr, targetList)
    n = dtmcStr.n

    '2. Compute TargetVector'
    b = ReachProb.computeTargetVector_Total(dtmcStr, targetList)

    '3. Compute res1V of DTMC'
    res1V = myfunCN(A,b,100)

    ' 4 - get index of the initial state. RULE : only one state is INITIAL'
    initialState = dtmcStr.initialSt[0]
    indexInitState = dtmcStr.indexDict[initialState.idState]

    '5. Compute a CN for each sub-vector of x'
    cnList = []
    coefDict = {}
    for subVectorId in pertDict.keys():
        'a. Get position of variables based on A'
        posIndexVarList = getPositionVariables(dtmcStr,subVectorId,pertDict,A)

        'b. Get CMatrix List based on posIndexVarList'
        clusterH = pertDict.get(subVectorId)
        cListClusterVar = getCMatrixListClusterVar(dtmcStr,targetList,clusterH)

        'c. Compute coefList for each CMatrix'
        coefList = []
        clusterVarCoefList = []
        for (clusterVar,cMatrix) in cListClusterVar:
            'if cmatrix is non-zero'
            if cMatrix.sum() !=  0:
                cB = cMatrix.dot(res1V)
                print "cMatrix: ", cMatrix
                print "cB " , cB
                res =  myfunCN(A,cB,100)
                print "cb + A*cb + A^2*cb + ... ", res
                coef = res[indexInitState,0]
                coefList.append(coef)
                clusterVarCoefList.append((clusterVar,coef))
            else:
                'it means that the variable is in targeList then cB'
                cB = createCB(dtmcStr.n,targetList,dtmcStr.indexDict,clusterH)
                print "nw_cB " , cB
                res =  myfunCN(A,cB,100)
                print "cb + A*cb + A^2*cb + ... ", res
                coef = res[indexInitState,0]
                coefList.append(coef)
                clusterVarCoefList.append((clusterVar,coef))
        '-- end for --'
        print " CLUSTERH: ", clusterH, " ---- COEF LIST : ", coefList
        print "clusterVarCoefList ", clusterVarCoefList

        'add into coefDict '
        coefDict[subVectorId] = clusterVarCoefList
    '-- end for -- '

    
    return coefDict.copy()

'------------------------------------------------------------------------'


