
import UtilFunctions, ReduciblePertCase, IrreduciblePertCase


"""
--- Compute Kappa for a reducible and irreducible DTMC
--- Output: Condition Number
"""
def computeLongRunKappa(dtmcStr,targetList,pertDict) :

    '0. get the TARGET state -- It should be one '
    targetSt = targetList[0]
    'get index of targSt'
    index_targSt = dtmcStr.indexDict.get(targetSt)


    '---- Step 1: Indentification of BSCCs of the DTMC'
    bsccList = UtilFunctions.getBSCCs(dtmcStr)
    print "BSCCs: ", bsccList
    print " --- "

    kappaLongRun = 0
    '---- Step 2: Identify if MC is reducible or irreducible '
    if isReducible(dtmcStr, bsccList) == True:
        kappaLongRun  = ReduciblePertCase.computeKappaRed(dtmcStr,targetList,pertDict)
    else:
        kappaLongRun = IrreduciblePertCase.computeKappaIrr(dtmcStr,targetList,pertDict)

    print "kappaLongRun: ", kappaLongRun


'--------------------------------------------------------------------'


'Function that identifies if the DTMC is reducible or irreducible'
def isReducible(dtmcStr, bsccList):

        if len(bsccList) > 1:
                return True
        if len(bsccList) == 1:
                idStList = dtmcStr.getIdStateList()
                bscc = bsccList[0]
                if  bscc == idStList:
                        return False
                else:
                        return True
'--------------------------------------------------------------------'
