from scipy.sparse import csr_matrix, lil_matrix
import UtilFunctions
import itertools


"""
--- Compute Condition number based on linear Fragment (coefDict)
the key of coefdict is subVectorId OF pertDict
"""

def computeKappaIrr(dtmcStr,targetList,pertDict):

    '1. Get linear Fragment'
    coefDict = mainFun_LinearFragment(dtmcStr,targetList,pertDict)
    print "coefDict: "
    for subVectorId in coefDict:
        print subVectorId, " --> ", coefDict.get(subVectorId)

    '2. ---'
    cnList = []
    for subVectorId in coefDict.keys():

        clusterVarCoefList = coefDict.get(subVectorId)

        'taking just coef of each element'
        coefList = [ coef  for  (clusterVar,coef,N) in clusterVarCoefList ]
        'taking N'
        (cl,c,N) = clusterVarCoefList[0]
        condNumN = computeConditionNumber(coefList, N)

        cnList.append(condNumN)
    '-- end for --'

    kappaIrr = max(cnList)
    print "--- Kappa Irr --- ", kappaIrr

    return kappaIrr


'-------------------------------------------------------------------------'

"""
--- Function that computes condition number
"""
def computeConditionNumber(coefList,N):
    condNum = 0
    if len(coefList) > 1:
        'get maximum and minimum cn'
        maxCN = max(coefList)
        minCN = min(coefList)
        'compute the condition number'
        condNum = (maxCN - minCN) / 2
    elif len(cnList) == 1:
        print "EROORRRRRRRRRRRRRRRRRRRRRR"
        
        'condNum = (coefList[0]) / 2'
    'print "condNum -- ", condNum'

    return condNum


'------------------------------------------------------------------------'

"""
Function that computes the linear Fragment
returns a coef Dict   subVectorId -> [(clusterVar,coef,N)]
"""
def mainFun_LinearFragment(dtmcStr,targetList,pertDict):


    '0. get the TARGET state -- It should be one '
    targetSt = targetList[0]
    'get index of targSt'
    index_targSt = dtmcStr.indexDict.get(targetSt)

    '1. get transition matrix'
    P = dtmcStr.getMatrixProb()

    '2. get the size of P'
    sizeP = dtmcStr.n

    '3. get idStateList '
    idStList =  dtmcStr.getIdStateList()

    condNumN = 0
    coefDict = {}

    '--- initialize power matrix Dict'
    powerMatrixPDict = {}

    '4. compute for each sub-vector of X'
    for subVectorId in pertDict.keys():

        'a. Get CMatrix Dict based on posIndexVarList'
        clusterH = pertDict.get(subVectorId)
        cMatrixClusterVarList = getCMatrixClusterVarList(dtmcStr,clusterH)


        'b. Create keyDict based on keys of cMatrixDict'
        sumResDict = {}
        keyDict = {}
        key = 1
        for (clusterVar, cMatrix) in cMatrixClusterVarList:
            sumResDict[key] = None
            keyDict[key] = clusterVar
            key = key + 1
        '-- end for --'
        key = None

        'c. compute the long N ---'
        N=1

        'd. initialize the result matrix '
        sumResMatrix = csr_matrix((sizeP,sizeP))

        condNumN = 0
        condNumN_1 = 0

        while True:

            print "N = ", N

            '1. Compute Sequence List '
            sequenceList = generateCombinations_Sum(N)
            print "seq: ", sequenceList

            coefList = []
            coefClusterVarList = []
            for (clusterVar,cMatrix) in cMatrixClusterVarList:

                '2. Compute the sum of permutations'
                sumPertMatrix = computeSum_PermutationMatrices(P,sizeP,cMatrix,sequenceList,powerMatrixPDict)

                '3. Update in sumResDict'
                'a) get key from keyDict based on clusterVar'
                key = getKey_ClusterVar(keyDict,clusterVar)
                'b) Update'
                if sumResDict.has_key(key):
                    currentMatrix = sumResDict.get(key)
                    if currentMatrix == None:
                        'P^0P*P^0'
                        sumResDict[key] = sumPertMatrix
                    else:
                        "P(N-1) + P(N)"
                        sumResDict[key] = currentMatrix + sumPertMatrix
                '-- end if --'
                sumResMatrix = sumResDict.get(key)


                '5. Compute coef'
                coef = computeCoef(sumResMatrix, N, targetSt, index_targSt, dtmcStr)
                coefList.append(coef)
                coefClusterVarList.append((clusterVar,coef,N))

            '-- end for --'

            print "CoefList : ", coefList
            condNumN = computeConditionNumber(coefList, N)
            print "condNum (N-1) -- ", condNumN_1
            print "condNum (N) -- ", condNumN
            print "dif : ", abs(condNumN_1 - condNumN)

            '------ Fail Condition -----'
            'if abs(condNumN_1 - condNumN) < 0.001 and abs(condNumN_1 - condNumN) > 0 :'
            if N==100:
                break
            else:
                condNumN_1 = condNumN
                N = N+1

        '-- end while --'
        coefDict[subVectorId] = coefClusterVarList
    '-- end for -- '
    return coefDict.copy()
'------------------------------------------------------------------------'

"""
Function that returns CMatrix based on clusterVar List
"""
def getCMatrixClusterVarList(dtmc,clusterH):

    cMatrixClusterVarList = []

    for clusterVar in clusterH:
        CMatrix = csr_matrix((dtmc.n,dtmc.n))
        for (i,j) in clusterVar:
            indexI = dtmc.indexDict.get(i)
            indexJ = dtmc.indexDict.get(j)
            CMatrix[indexI,indexJ] = 1
        '-- end for (i,j) --'
        cMatrixClusterVarList.append((clusterVar,CMatrix))
    '-- end for --'
    return cMatrixClusterVarList


'-------------------------------------------------------------------------'



"""
------ this function generates all combinations of 2 numbers which sum is equal k-1
"""
def generateCombinations_Sum(k):

    numbers = range(0,k)
    'print "numbers: ", numbers'
    result = [seq for seq in itertools.combinations_with_replacement(numbers,2) if sum(seq) == k-1]
    reverseList = [ (b,a) for (a,b) in result if a != b]
    return result + reverseList

'-------------------------------------------------------------------------'

"""
----- Compute the sum of the permutation of matrices based on a sequence
----- \sum_{k=1}^{N} \sum_{i,j \leq 0 and i + j = k-1} P^jP*P^i
"""
def computeSum_PermutationMatrices(P,sizeP,cMatrix,sequenceList,powerMatrixPDict):

    powerM_i = csr_matrix((sizeP,sizeP))
    powerM_j = csr_matrix((sizeP,sizeP))
    resMatrixPartial = csr_matrix((sizeP,sizeP))
    resMatrix = csr_matrix((sizeP,sizeP))

    sumResultMatrix = csr_matrix((sizeP,sizeP))
    for (i,j) in sequenceList:

        '1. calculate P^j and P^i'
        if i == j:
            powerM_i = computePower_Dict(P,i,sizeP,powerMatrixPDict)
            powerM_j = powerM_i

        else:
            powerM_i = computePower_Dict(P,i,sizeP,powerMatrixPDict)
            powerM_j = computePower_Dict(P,j,sizeP,powerMatrixPDict)


        '2. calculate P^jP*P^i'
        resMatrixPartial = powerM_j.dot(cMatrix)
        resMatrix = resMatrixPartial.dot(powerM_i)

        '3. calculate sum '
        sumResultMatrix = sumResultMatrix + resMatrix
    '-- end for --'
    'print "sumResultMatrix: "'
    'print sumResultMatrix'
    return sumResultMatrix

'------------------------------------------------------------------------'

'Function that return key based on value'
def getKey_ClusterVar(keyDict,clusterVar):

    for key in keyDict.keys():

        value = keyDict.get(key)
        if value == clusterVar:
            return key

'-------------------------------------------------------------------------'


'-- Function that compute coef based on Cmatrix and sumPertMatrix'
def computeCoef(sumPertMatrix, N, targetSt,index_targSt, dtmcStr):

    '1. get idStateList '
    idStList =  dtmcStr.getIdStateList()

    sumStates = 0
    for idSt in idStList:
        'a. get index of idSt'
        index_idSt =  dtmcStr.indexDict.get(idSt)
        'b. get value of sumPertMatrix'
        value = sumPertMatrix[index_idSt,index_targSt]
        'c. sum of states'
        sumStates = sumStates + value
    '--- end for '
    'print "sumStates: ",sumStates'

    'divide by 1\n'
    constN = 1/float(N)
    nw_sumStates = sumStates * constN

    return nw_sumStates

'------------------------------------------------------------------------'

'Function that computes power of P based on powerMatrixDict'
def computePower_Dict(P,n,sizeP,powerMatrixPDict):

    keyList = powerMatrixPDict.keys()

    if len(keyList) == 0:
        powerM = UtilFunctions.powerMatrix(P,n,sizeP)
        powerMatrixPDict[n] = powerM
    else:
        if n in keyList:
            powerM = powerMatrixPDict.get(n)
        else:
            if n-1 in keyList:
                powerN_1 = powerMatrixPDict.get(n-1)
                powerM = powerN_1.dot(P)
                powerMatrixPDict[n] = powerM
            else:
                powerM = UtilFunctions.powerMatrix(P,n,sizeP)
                powerMatrixPDict[n] = powerM

    return powerM




'-------------------------------------------------------------------------'

