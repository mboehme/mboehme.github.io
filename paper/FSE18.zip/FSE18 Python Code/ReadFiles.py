
import sys, re
import DTMCStructure

"""
------------------ MAIN FUNCTION ------------------------
Output: DTMC structure
"""
def convert_toDtmc():

    '1.  Build the DTMC based on states and transitionMatrix files'
    dtmcStr = main_readFiles(sys.argv[1:3])
    return dtmcStr


'---------------------------------------------------------'

"""
 Input:  File Names from console
 Output: DTMC instance
"""
def main_readFiles(arglist):
    'python main.py fileStates fileTrans'

    fnameStates = arglist[0]
    fnameTrans = arglist[1]

    with open(fnameStates, 'r') as f:
        contentStates = f.readlines()
        (initSt, nw_stateList) = toStateList(contentStates)

    with open(fnameTrans, 'r') as f:
        contentTrans = f.readlines()
        transDict = toTransitionMatrix(contentTrans)

    'Convert the labels of initial states to list of states'
    initialStates = toStates(initSt, nw_stateList)

    'Create a DTMC'
    dtmcStr = DTMCStructure.DTMC(nw_stateList,transDict, initialStates)

    return dtmcStr

'----------------------------------------------------------------'

"""
 Input : States File
 Output : StateList [(idx, state)]
"""
def toStateList(statesFile):

    'first line is initial State'
    fstLine = statesFile[0].strip().split(' ')
    initList = [int(elem) for elem in fstLine]
    

    'Discard first line'
    nw_statesFile = statesFile[1:]
    'parse the file'
    stateList = []
    for line in nw_statesFile:
        spLine = line.strip().split(':')
        idState = int(spLine[0])
        labelStBrac = spLine[-1]
        lenLabel = len(labelStBrac)
        nameState = labelStBrac[0:lenLabel]
        nw_state = DTMCStructure.State(idState,nameState)
        stateList.append(nw_state)
    '-- end for --'

    return (initList,stateList)
'----------------------------------------------------------------'

"""
 Input: Transitions File
 Output: Dict Transitions
"""
def toTransitionMatrix(transFile):
    'Discard first line'
    nw_transFile = transFile[1:]

    transDict={}
    
    for line in nw_transFile:
        spline = line.strip().split(' ')

        fromSt = int(spline[0])
        nw_transition = DTMCStructure.Transition(fromSt, spline[1], spline[2])
        
        'update the transition dict'
        if transDict.has_key(fromSt) == True:
            value = transDict.get(fromSt)
            value.append(nw_transition)
            transDict[fromSt] = value
        else:
            listvalues = []
            listvalues.append(nw_transition)
            transDict[fromSt] = listvalues
    '-- end for --'
    return transDict.copy()
'----------------------------------------------------------------'

"""
 Input: List of Initial States, State List
 Output: State List
"""
'Convert the labels of initial states to list of states'
def toStates(initList, stateList):
    return [state for state in stateList if state.idState in initList]
'----------------------------------------------------------------'

"""
--- TARGET File -----------------------------------------------
Read the target state
"""
def readTargetFile():


    fnameTarget = sys.argv[3]

    with open(fnameTarget, 'r') as f:
        contentTarget = f.readlines()
        targetList = []
        for item in contentTarget:
            targetList.append(int(item))

    f.close()
    print "TargetList: ", targetList
    
    return targetList
'----------------------------------------------------------------'



"""
--- PERTURBATION File -------------------------
-----------------------------------------
"""
def readPerturbationFile(dtmcStr):

    pertNameFile = sys.argv[4]
    
    with open(pertNameFile, 'r') as f:

        'perturbation Dict'
        pertDict = {}

        'initial value of keyH'
        keyH = 0

        clusterH = []
        clusterVar = []

        for item in f.readlines():
            linelist = item.strip().split(' ')
            
            if len(linelist) == 1:
                'it means that the line is --- or ==='
                text = linelist[0]
                if text == "===":
                    'it means that we start a new sub-vector x'
                    if len(clusterVar) > 0:
                        clusterH.append(clusterVar)
                        clusterVar = []
                    if len(clusterH) > 0:
                        pertDict[keyH] = clusterH
                        clusterH = []
                    keyH = keyH + 1
                if text == "---":
                    'it means that we start a clusterVar'
                    if len(clusterVar) > 0:
                        clusterH.append(clusterVar)
                        clusterVar = []
            else:
                'print "linelist ", linelist'
                idxStFrom = int(linelist[0])
                idxStTo = int(linelist[1])
                clusterVar.append((idxStFrom,idxStTo))
        
        '-- end for --'
    
        print "PerturbationDict : "
        for key in pertDict.keys():
            print key,  " -> ", pertDict.get(key)
        '-- end for --'
    f.close()
    return pertDict
'----------------------------------------------------------------'


