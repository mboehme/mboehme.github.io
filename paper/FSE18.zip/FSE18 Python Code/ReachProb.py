
from scipy.sparse import csr_matrix, lil_matrix


"""
---- MAIN FUNCTION: Compute reachProb
"""
def computeReachProb(dtmc,targetList):

    '1.Compute Testing Matrix'
    A = computeTestingMatrix_Total(dtmc, targetList)

    '2.Compute Target Vector'
    b = computeTargetVector_Total(dtmc, targetList)

    if b.sum()==0: return 0

    '3.Compute ProbReach'
    'a. Get initial state'
    initialState = dtmc.initialSt[0]
    indexInitState = dtmc.indexDict[initialState.idState]

    probVector = computeProb(A,b,100)

    prob = probVector[indexInitState,0]

    return prob


'--------------------------------------------------------------'

"""
-------------- TESTING MATRIX ----------------------------
It is based only the advDict that you give.
Note advDict is set S? and target is not part of Srest
"""
'Compute Testing matrix, replace the col and row by zeros according to target set '
'Return CSR Matrix'
def computeTestingMatrix_Total(dtmc, targetList):
    'get index of target set'
    targetIdxs = [dtmc.indexDict[targSt] for targSt in targetList]
    indexList = dtmc.indexDict.values()
    matrixLIL = dtmc.getMatrixProb()
    
    for idxtarg in targetIdxs:
        for i in indexList:
            matrixLIL[i,idxtarg] = 0
            matrixLIL[idxtarg,i] = 0

    return matrixLIL.tocsr()
'------------------------------------------------------------------------'

""" -------------- TARGET VECTOR ----------------------
---- Compute TargetVector based on S? 
"""
'Compute TargetVector, sum the cols w.r.t. targetList'
def computeTargetVector_Total(dtmc, targetList):
    targetIdxs = [dtmc.indexDict[targSt] for targSt in targetList]
    matrixLIL = dtmc.getMatrixProb()
    sumM = lil_matrix((dtmc.n,1))
    for idxTar in targetIdxs:
        sumM = sumM + matrixLIL.getcol(idxTar)
        'clean the pos w.r.t idxTar'
        sumM[idxTar] = 0
    return sumM
'------------------------------------------------------------------------'

""" ---------------- PROBABILITY ---------------------
---- Function that computes the reachability probabily
-- A : testing matrix, b:targetVector, n: exponent of A (expresses precision)
"""
def computeProb(A,b,n):
    sumT = b
    Ac = A
    for i in  range(1,n):
        z = Ac.dot(b)
        sumT = sumT + z
        Ac = A.dot(Ac)
    return sumT
'------------------------------------------------------------------------'
