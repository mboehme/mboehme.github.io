import UtilFunctions

""" -------------------------------------------------------------
----- Compute SCC on the DTMC
"""
def computeSCC(dtmcStr):
    'get idxStateList'
    S = dtmcStr.getIdStateList()
    'get initial State'
    initialState = dtmcStr.initialSt
    if len(initialState) == 1:
        initSt = initialState[0]
        idxS = initSt.idState
    else:
        if len(initialState) == 0:
            'it is subMdp'
            idxS = S[0]
        else:
            print "REPORT : COMPUTESCC - Reachability.py"
            return


    'fill the tarjanDic: convert state to TarjanState'
    tarjanDict = {}
    for st in S:
        tarjanDict[st] = TarjanState(st)

    'call tarjanAlgorithm'
    stack = []
    sccList = []

    tarjanAlgorithm(idxS, tarjanDict,  dtmcStr, stack, sccList)
    global index
    index = 1
    return sccList

'----------------------------------------------------------------------------'
""" THE TARJAN ALGORITHM : COMPUTATION OF SCC COMPONENTS
"""
class TarjanState:
    idxSt = -1
    index = -1
    lowlink = -1

    def __init__(self, idxSt):
        self.index = -1
        self.lowlink = 0
        self.idxSt = idxSt

    def __repr__(self):
        return "TarjanSt %s:(%s,%s)" % (self.idxSt,self.index, self.lowlink)

'Global Variable'
index =  1

def nwTarjanSet( idxSt, index, lowlink):
        nwT = TarjanState(idxSt)
        nwT.index = index
        nwT.lowlink = lowlink
        return nwTarjanSet

' ---------------  TARJAN ALGORITHM  ----------------------'
def tarjanAlgorithm(idxS, tarjanDict,  dtmcStr, stack, sccList):
    s = tarjanDict[idxS]
    s.index = index
    s.lowlink = index
    stack.append(s)
    global index
    index= index + 1
    transList = dtmcStr.getNonProbabilisticTM(idxS)
    for trans in transList:
        idxSprima = trans[1]
        sprima = tarjanDict[idxSprima]
        if sprima.index == -1:
            tarjanAlgorithm(idxSprima, tarjanDict, dtmcStr, stack, sccList)
            s.lowlink = minLowLink(s.lowlink, sprima.lowlink)
        elif isInStack(sprima,stack):
            s.lowlink = minLowLink(s.lowlink, sprima.lowlink)

    'start new SCC'
    'the whole SCC is popped from stack'
    if s.lowlink == s.index:
        lis = []
        while (len(stack) > 0):
            if top(stack).index >= s.index:
                scc = stack.pop()
                lis.append(scc.idxSt)
            else:
                break
        if len(lis) > 0:
            lis.sort()
            'topological order'
            'print "SCC: " , lis , " - " , s.index'
            sccList.append(lis)
    else:
        if(isInStack(s,stack) == False):
            stack.append(s.idxSt)
'-----------------------------------------------------------'

def minLowLink(a,b):
    if a == 0:
        return b
    elif b == 0:
        return a
    else: return min(a,b)

def isInStack(s,stack):
    for elem in stack:
        if elem.idxSt == s.idxSt:
            return True
    return False

def top(stack):
    return stack[(len(stack)-1)]


