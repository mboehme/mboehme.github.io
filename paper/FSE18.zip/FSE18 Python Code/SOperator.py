
import UtilFunctions, ReachProb
from scipy.sparse import csr_matrix, lil_matrix

"""
--- Main Functions 
"""
def mainComputeSProp(dtmcStr,targetList):

        '0. get the TARGET state -- It should be one '
        targetSt = targetList[0]
        'get index of targSt'
        index_targSt = dtmcStr.indexDict.get(targetSt)


	'---- Step 1: Indentification of BSCCs of the DTMC'
	bsccList = UtilFunctions.getBSCCs(dtmcStr)
	print "BSCCs: ", bsccList
        print " --- "

        steadyProb = 0
        '---- Step 2: Identify if MC is reducible or irreducible '
        if isReducible(dtmcStr, bsccList) == True:
                steadyProb = computeLongRun_Reducible(dtmcStr,bsccList,targetSt,index_targSt)
        else:
                steadyProb = computeLongRun_Irreducible(dtmcStr,targetSt,index_targSt)

        return steadyProb

'---------------------------------------------------------'

'Function that identifies if MC is reducible or irreducible'
def isReducible(dtmcStr, bsccList):

        if len(bsccList) > 1:
                return True
        if len(bsccList) == 1:
                idStList = dtmcStr.getIdStateList()
                bscc = bsccList[0]
                if  bscc == idStList:
                        return False
                else:
                        return True


'---------------------------------------------------------'


'Function that compute LongRun Irreducible Case'
def computeLongRun_Irreducible(dtmcStr,targetSt,index_targSt):

        '1. get transition matrix'
        P = dtmcStr.getMatrixProb()

        '2. get the size of P'
        sizeP = dtmcStr.n

        '3. get idStateList '
        idStList =  dtmcStr.getIdStateList()

        '4. compute the long N'
        N = 1

        resN = 0
        resN_1 = 0

        'Initialize matrix sumPowerP'
        sumPowerP = csr_matrix((sizeP,sizeP))

        '--- initialize power matrix Dict'
        powerMatrixPDict = {}

        while True:

                print "N = ", N

                'Compute sum power of P w.r.t N '

                'powerMatrix = UtilFunctions.powerMatrix(P,N,sizeP)'
                powerMatrix = computePower_Dict(P,N,sizeP,powerMatrixPDict)
                sumPowerP = sumPowerP + powerMatrix
                'print "sumPowerP : ", sumPowerP'

                sumStates = 0

                'for every state '
                for idSt in idStList:
                        'a. get index of idSt'
                        index_idSt =  dtmcStr.indexDict.get(idSt)
                        'b. get value of sumProbN'
                        value = sumPowerP[index_idSt,index_targSt]
                        'c. sum of states'
                        sumStates = sumStates + value
                '--- end for '
                'print "sumStates: ",sumStates'

                'Compute 1/n'
                constN = 1/ float(N)
                'print "constN: ", constN'

                'compute resN'
                resN =  (constN * sumStates)
                'print "resN --- ",  resN'
                'print "resN_1 --- ",  resN_1'
                print "dif : ", resN_1 - resN
                '-------------- Fail condition --------------'
                'if abs(resN_1 - resN) < 0.0001 and abs(resN_1 - resN) > 0:'
                'for perturbed scenario 0.00001'
                if abs(resN_1 - resN) < 0.0000001 and abs(resN_1 - resN) > 0:
                        break
                else:
                        resN_1 = resN
                        N = N+1
        '---- end while ------------ '

        '5. Normalize the result'
        normResult = resN / len(idStList)

        'print "Normalize Result: ", normResult'

        return normResult

'------------------------------------------------------------------------'
'Function that computes power of P based on powerMatrixDict'
def computePower_Dict(P,n,sizeP,powerMatrixPDict):

    keyList = powerMatrixPDict.keys()

    if len(keyList) == 0:
        powerM = UtilFunctions.powerMatrix(P,n,sizeP)
        powerMatrixPDict[n] = powerM
    else:
        if n in keyList:
            powerM = powerMatrixPDict.get(n)
        else:
            if n-1 in keyList:
                powerN_1 = powerMatrixPDict.get(n-1)
                powerM = powerN_1.dot(P)
                powerMatrixPDict[n] = powerM
            else:
                powerM = UtilFunctions.powerMatrix(P,n,sizeP)
                powerMatrixPDict[n] = powerM

    return powerM


'---------------------------------------------------------'


'---------------------------------------------------------'
'Function that compute LongRun Reducible Case'
def computeLongRun_Reducible(dtmcStr,bsccList,targetSt,index_targSt):

        '1. get idStateList '
        idStList =  dtmcStr.getIdStateList()

        '2. get BsccStates'
        bsccStates = [ s for bscc in bsccList for s in bscc]

        if targetSt not in bsccStates:
                return 0

        '3. Indentify the BSCC where targetSt belongs'
        targetBscc = UtilFunctions.getBSCC(bsccList,targetSt)

        '4. Compute sub-MC'
        subMC = UtilFunctions.subMC_BSCC(dtmcStr,targetBscc)
        'subMC.displayDTMC()'

        '5. Compute reachProb'
        reachProbTarget = ReachProb.computeReachProb(dtmcStr,[targetSt])
        'print reachProbTarget'

        '6. Compute steadyState in BSCC'
        indexBSCC_targSt = subMC.indexDict.get(targetSt)
        longrunBsccTarget = computeLongRun_Irreducible(subMC,targetSt,indexBSCC_targSt)

        print "longrunBscc - ", longrunBsccTarget
        steadyProb = reachProbTarget * longrunBsccTarget

        return steadyProb


'---------------------------------------------------------'
