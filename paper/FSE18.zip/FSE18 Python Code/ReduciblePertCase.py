
import UtilFunctions,ReachProb, SOperator, ConditionNumber


"""
--- Compute CN for Reducible DTMCs
--- Input: DtmcStr, Target State, Perturbation
--- Output: CN
"""
def computeKappaRed(dtmcStr,targetList,pertDict):

    '1. Get Linear Fragrment '
    coefDict = mainFun_LinearFragment(dtmcStr,targetList,pertDict)


    cnList = []
    for subVectorId in coefDict.keys():

        clusterVarCoefList = coefDict.get(subVectorId)

        coefList = [ coef for (clusterVar,coef) in clusterVarCoefList ]
        condNum = computeConditionNumber(coefList)

        cnList.append(condNum)

    '--- end for --'

    kappaRed = max(cnList)
    print "--- Kappa Red --- ", kappaRed

    return kappaRed

'--------------------------------------------------------------------'

"""
--- Compute the linear fragment for Reducible DTMC
--- Output List of coef 
"""
def mainFun_LinearFragment(dtmcStr,targetList,pertDict):


    '0. get the TARGET state -- It should be one '
    targetSt = targetList[0]
    'get index of targSt'
    index_targSt = dtmcStr.indexDict.get(targetSt)

    '1: Indentification of BSCCs of the DTMC'
    bsccList = UtilFunctions.getBSCCs(dtmcStr)
    print "BSCCs: ", bsccList
    print " --- "

    '2. get BsccStates'
    bsccStates = [ s for bscc in bsccList for s in bscc]

    if targetSt not in bsccStates:
        return 0

    '3. Indentify the BSCC where targetSt belongs'
    targetBscc = UtilFunctions.getBSCC(bsccList,targetSt)

    inputSt_targetBscc = UtilFunctions.getInputState_BSCC(dtmcStr, targetBscc)

    '4. Compute sub-MC'
    subMC = UtilFunctions.subMC_BSCC(dtmcStr,targetBscc)
    'subMC.displayDTMC()'

    'compute PertDict_subMC based on PertDictX'
    subPertDict = get_subPertDict(pertDict,subMC)
    print "=== SubPertDict ====", subPertDict

    '5. ReachProb'
    probReach = ReachProb.computeReachProb(dtmcStr,targetList)
    print "PROBREACH -- ", probReach

    '6. linear Fragment Irreducible'
    IrreCoefDict = IrreduciblePertCase.mainFun_LinearFragment(subMC,targetList,subPertDict)
    print "IrreCoefDict: "
    for subVectorId in IrreCoefDict:
        print subVectorId, " --> ", IrreCoefDict.get(subVectorId)

    '7. Compute long-run probability'
    'new index_targetSt'
    nw_index_targSt = subMC.indexDict.get(targetSt)
    steadyProb = SOperator.computeLongRun_Irreducible(subMC,targetSt,nw_index_targSt)
    print "STEADYPROB --", steadyProb

    '8. linear Fragment Reachability'
    ReachCoefDict = ConditionNumber.linearFragmentReach(dtmcStr,targetList,pertDict)
    print "Reach coefDict "
    for key in ReachCoefDict.keys():
        print key , " --> ", ReachCoefDict.get(key)
    '-- end for -- '

    '---- Computing Linear Fragment -------'
    coefTotalDict = {}

    'A. ProbReach * IrreducibleCoef'
    for subVectorId in IrreCoefDict.keys():

        'get value '
        valueList = IrreCoefDict.get(subVectorId)

        nwList = []
        for(clusterVar,coefIrr,N) in valueList:
            nw_coef = 1/float(N) * coefIrr * probReach
            nwList.append((clusterVar,nw_coef))
        '-- end for --'
        coefTotalDict[subVectorId] = nwList
    '-- end for --'
    print coefTotalDict
    print "===== B ------"
    'B. steadyProp * linearFragReach'
    for subVectorId in ReachCoefDict.keys():
        'get value '
        valueList = ReachCoefDict.get(subVectorId)
        
        if coefTotalDict.has_key(subVectorId):
            'coefValueList'
            coefValueList = coefTotalDict.get(subVectorId)

            nw_coefValueList =[]
            for (clusterVar,coef) in valueList:

                val =  findClusterVar(coefValueList,clusterVar)
                if val == None:
                     nw_coefValueList.append((clusterVar,coef))
                else:
                    nw_coef = val[1] + (steadyProb * coef)
                    nw_coefValueList.append((clusterVar,nw_coef))
            '-- end for --'
            coefTotalDict[subVectorId] = nw_coefValueList
        else:
            nw_coefList = [ (clusV, coef * steadyProb )  for (clusV,coef) in valueList] 
            coefTotalDict[subVectorId] = nw_coefList
    '-- end for --'
    print " *****  COEF TOTAL *******"
    for key in coefTotalDict.keys():
        print key , " --> ", coefTotalDict.get(key)
    '-- end for -- '

    return coefTotalDict.copy()

'--------------------------------------------------------'

"""
-- Function that filters the perturbation based on transition 
"""
def get_subPertDict(pertDictX,subMC):

    idStList = subMC.getIdStateList()

    subPertDict = {}

    for key in pertDictX.keys():
        clusterVar = pertDictX.get(key)

        'get the state where the clusterVar is'
        tempList = [fromSt for (fromSt, toSt) in clusterVar[0]]
        fromState = tempList[0]

        'add in subPertDict'
        if fromState in idStList:
            subPertDict[key] = clusterVar
    '-- end for --'
    return subPertDict.copy()
'--------------------------------------------------------'




