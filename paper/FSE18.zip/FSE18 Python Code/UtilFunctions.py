from scipy.sparse import csr_matrix, lil_matrix
import TarjanAlgorithm, DTMCStructure

'Function that create IndexList (dict) where key is idxSt and value is index in the matrix'
def get_IndexDict(stateList):
    indexDict = {}
    i = 0
    for idxSt in stateList:
        indexDict[idxSt] = i
        i = i+1
    return indexDict
'------------------------------------------------------------------------'

""" -------------------------------------------------------------------
Input: List of tuples
Output: List without duplicate tuples
"""
def eliminateDuplicates(list1):
    resList = []
    for elem in list1:
        if elem not in resList:
            resList.append(elem)
    return resList


""" ------------------------------------------------------------------
Appy bool functions to a list
"""
def applyAND(list1):
    res = list1[0]
    for elem in list1[1:]:
        res = res & elem
    return res

def applyOR(list1):
    res = list1[0]
    for elem in list1[1:]:
       res = res | elem
    return res

""" -------------------------------------------------------------------
Function that computes the power of a Matrix
"""
def powerMatrix(P,k,sizeP):

    if k == 0:
        'build identity matrix'
        identityMatrix =  csr_matrix((sizeP,sizeP))
        for i in range(0,sizeP):
            identityMatrix[i,i] = 1
        return identityMatrix
    if k == 1:
        return P
    if k > 1:
        res = P
        for i in range(2,k+1):
            res = res.dot(P)
        '-- end for --'
        return res
'-----------------------------------------------------------------------'

'---------------------------------------------------------'
'Function of sumProd of a matrix P from 1 to N'
def sumProd(P,N,sizeP):

        resSum = csr_matrix((sizeP,sizeP))
        if N == 1:
            resSum = P
        if N > 1:
            for k in range(1,N+1):
                print "k : ", k
                powerRes = powerMatrix(P,k,sizeP)
                print powerRes
                resSum  = resSum + powerRes
                print "resSum: ", resSum
            '---- end for -----'
        '--- end if ---'
        return resSum
'-----------------------------------------------------------------------'

'Function that identifies if a SCC is a BSCC'
def isBSCC(scc, dtmcStr):

	boolList = []
	for idSt in scc:

		tranList_idSt = dtmcStr.getTransitionList(idSt)
		toStList_bool = [tran.toSt in scc for tran in tranList_idSt ]
		boolList.append(applyAND(toStList_bool))
	'-- end for --'
	return applyAND(boolList)

'---------------------------------------------------------'

'Function that returns the set of BSCC of a DTMC'
def getBSCCs(dtmcStr):

	'1. get the SCCs'
	sccList = TarjanAlgorithm.computeSCC(dtmcStr)
	'print "SCC List: ", sccList'

	bsccList = []
	for scc in sccList:
		if  isBSCC(scc,dtmcStr) == True:
			bsccList.append(scc)
	'-- end for --'

	return bsccList
'---------------------------------------------------------'

'Function that returns the BSCC where idstate belongs'
' FOR SURE idState is in a BSCC'
def getBSCC(bsccList,idState):

    for bscc in bsccList:
        if idState in bscc:
            return  bscc
    '-- end for --'
'---------------------------------------------------------'

'Function that return sub-MC based on BSCC'
def subMC_BSCC(dtmcStr,bscc):

    '----- States --------'
    stateList = []
    for idSt in bscc:
        nw_state = DTMCStructure.State(idSt,idSt)
        stateList.append(nw_state)
    '-- end for --'
    idStateList = bscc

    '----- transDict --------'
    transDict={}

    for idState in idStateList:
        transList = dtmcStr.getTransitionList(idState)

        for nw_transition in transList:

            'update the transition dict'
            if transDict.has_key(nw_transition.fromSt) == True:
                value = transDict.get(nw_transition.fromSt)
                value.append(nw_transition)
                transDict[nw_transition.fromSt] = value
            else:
                listvalues = []
                listvalues.append(nw_transition)
                transDict[nw_transition.fromSt] = listvalues
        '-- end for -- '
    '-- end for --'

    '----- initialStates are input_States --------'
    inpStates = getInputState_BSCC(dtmcStr, bscc)
    'print "inpStates: ", inpStates'

    'Create a DTMC'
    dtmcStr = DTMCStructure.DTMC(stateList,transDict, inpStates)

    return dtmcStr
    
'---------------------------------------------------------'

'Function that returns the input state of a BSCC'
def getInputState_BSCC(dtmcStr, bscc):

    '1. get idStateList '
    idStList =  dtmcStr.getIdStateList()

    inputStList = []
    for idState in idStList:
        transList = dtmcStr.getTransitionList(idState)
        for trans in transList:
            if trans.toSt  in bscc and idState not in bscc:
                inputStList.append(trans.fromSt)
        '--- end for --'
    '-- end for --'

    return eliminateDuplicates(inputStList)

'---------------------------------------------------------'
